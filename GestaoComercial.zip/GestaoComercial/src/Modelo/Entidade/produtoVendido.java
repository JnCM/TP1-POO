
package Modelo.Entidade;

public class produtoVendido {
    private int qtde;
    private int codigoProduto;
    private double precoUnitario;

    public produtoVendido(int qtde, int codigoProduto, double precoUnitario) {
        this.qtde = qtde;
        this.codigoProduto = codigoProduto;
        this.precoUnitario = precoUnitario;
    }

    public int getQtde() {
        return qtde;
    }

    public double getPrecoUnitario() {
        return precoUnitario;
    }
    
}
