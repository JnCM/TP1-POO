
package Modelo.Entidade;
import java.util.ArrayList;

public class venda {
    private int codigo;
    private String dataInicio;
    private String dataFim;
    private String status;
    private int clienteDaVenda;
    private String enderecoDeEntrega;
    private ArrayList<produtoVendido> produtosVendidos;
    
    public venda(){}
    public venda(int codigo, String dataInicio, String status, int clienteDaVenda, String enderecoDeEntrega) {
        this.codigo = codigo;
        this.dataInicio = dataInicio;
        this.status = status;
        this.clienteDaVenda = clienteDaVenda;
        this.enderecoDeEntrega = enderecoDeEntrega;
        dataFim = null;
        produtosVendidos = new ArrayList();
    }

    public int getCodigo() {
        return codigo;
    }

    public String getDataInicio() {
        return dataInicio;
    }

    public String getDataFim() {
        return dataFim;
    }

    public String getStatus() {
        return status;
    }
    
    public void setDataFim(String dataFim) {
        this.dataFim = dataFim;
    }
    
    public void insereProdutoVendido(int qtde, int codigo, double preco){
        produtoVendido prod = new produtoVendido(qtde,codigo,preco);
        produtosVendidos.add(prod);
    }

    public void setStatus(String status) {
        this.status = status;
    } 
}
