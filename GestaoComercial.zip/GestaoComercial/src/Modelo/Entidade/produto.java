
package Modelo.Entidade;

public class produto {
    private int codigo;
    private String descricao;
    private int qtdeEmEstoque;
    private String categoria;
    private double preco;
    
    public produto(int codigo, String descricao, int qtdeEmEstoque, String categoria, double preco) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.qtdeEmEstoque = qtdeEmEstoque;
        this.categoria = categoria;
        this.preco = preco;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getQtdeEmEstoque() {
        return qtdeEmEstoque;
    }

    public String getCategoria() {
        return categoria;
    }
    
    public double getPreco() {
        return preco;
    }

    public int setQtdeEmEstoque(int qtde) {
        if(qtdeEmEstoque == 0){
            System.err.println("Produto nao disponivel em estoque!");
            return 0;
        }
        if(qtdeEmEstoque-qtde <= 0){
            System.err.println("Quantidade nao disponivel em estoque!");
            return 0;
        }
        qtdeEmEstoque-=qtde;
        return 1;
    }
    
    
}
