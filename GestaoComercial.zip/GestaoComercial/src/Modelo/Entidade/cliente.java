
package Modelo.Entidade;
import java.util.ArrayList;

public class cliente {
    private int codigo;
    private String cpf;
    private String nome;
    private String email;
    private String senha;
    private ArrayList<endereco> enderecos;
    
    public cliente(){}

    public cliente(int codigo, String cpf, String nome, String email, String senha){
        this.codigo = codigo;
        this.cpf = cpf;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        enderecos = new ArrayList();
    }
    public void insereEnderecos(String rua, String bairro, String cidade, int numero){
        endereco end = new endereco(rua, bairro, cidade, numero);
        enderecos.add(end);
    }
    
    public String getNome(){
        return nome;
    }
    
    public int getCodigo() {
        return codigo;
    }

    public String getCpf() {
        return cpf;
    }

    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public void setEnderecos(ArrayList<endereco> enderecos) {
        this.enderecos = enderecos;
    }
    
    public endereco buscaEndereco(int indice){
        return enderecos.get(indice);
    }
    public ArrayList<endereco> getListaEnderecos(){
        return enderecos;
    }
}
