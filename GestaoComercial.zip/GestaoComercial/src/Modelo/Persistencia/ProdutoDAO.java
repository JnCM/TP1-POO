
package Modelo.Persistencia;
import Modelo.Entidade.produto;
import java.util.ArrayList;

public class ProdutoDAO {
    private ArrayList<produto> produtos;

    public ProdutoDAO() {
        produtos = new ArrayList();
    }
    
    public int adicionaProduto(int codigo, String descricao, int qtdeEmEstoque, String categoria, double preco){
        for(produto p : produtos){
            if(p.getCodigo() == codigo){
                //System.err.println("Produto ja cadastrado!");
                return 0;
            }
        }
        produto prod = new produto(codigo,descricao,qtdeEmEstoque,categoria,preco);
        produtos.add(prod);
        //System.out.println("Produto cadastrado com sucesso!");
        return 1;
    }
    public int removeProduto(int codigo){
        for(produto p : produtos){
            if(p.getCodigo() == codigo){
                produtos.remove(p);
                //System.out.println("Produto removido com sucesso!");
                return 1;
            }
        }
        //System.err.println("Produto para remocao nao encontrado!");
        return 0;
    }
    public double buscaProduto(int codigo, int qtde){
        int aux;
        if(produtos.isEmpty()){
            //System.err.println("Nenhum produto cadastrado ate o momento!");
            return -1;
        }
        for(produto p : produtos){
            if(p.getCodigo() == codigo){
                aux = p.setQtdeEmEstoque(qtde);
                if(aux == 0){
                    return 0.0;
                }
                //System.out.println("Produto encontrado com sucesso!");
                return p.getPreco();
            }
        }
        //System.out.println("Produto nao encontrado!");
        return 0.0;
    }
    
    public int buscaProduto2(int codigo){
        if(produtos.isEmpty()){
            //System.err.println("Nenhum produto cadastrado ate o momento!");
            return -1;
        }
        for(produto p : produtos){
            if(p.getCodigo() == codigo){
                return 1;
            }
        }
        //System.out.println("Produto nao encontrado!");
        return 0;
    }
    
    public ArrayList<produto> getProdutos() {
        return produtos;
    }
    
}
