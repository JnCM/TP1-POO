
package Modelo.Persistencia;
import Modelo.Entidade.cliente;
import java.util.ArrayList;

public class ClienteDAO {
    private ArrayList<cliente> clientes;

    public ClienteDAO() {
        clientes = new ArrayList();
    }
    
    public int adicionaCliente(int codigo, String cpf, String nome, String email, String senha){
        for(cliente c : clientes){
            if(c.getCodigo() == codigo){
                //System.err.println("Codigo ja cadastrado!");
                return 0;
            }
            if(c.getCpf().equals(cpf)){
                //System.err.println("CPF ja cadastrado!");
                return -1;
            }
            if(c.getEmail().equals(email)){
                //System.err.println("Email ja cadastrado!");
                return -2;
            }
        }
        cliente cl = new cliente(codigo,cpf,nome,email,senha);
        clientes.add(cl);
        return 1;
    }
    
    public int adicionaEndereco(int codigo, String rua, String bairro, String cidade, int numero){
        for(cliente c : clientes){
            if(c.getCodigo() == codigo){
                c.insereEnderecos(rua, bairro, cidade, numero);
                return 1;
            }
        }
        return 0;
    }
    
    public int removeCliente(int codigo){
        for(cliente c : clientes){
            if(c.getCodigo() == codigo){
                clientes.remove(c);
                //System.out.println("Cliente removido com sucesso!");
                return 1;
            }
        }
        //System.err.println("Cliente para remocao nao encontrado!");
        return 0;
    }
    
    public int buscaCliente2(int codigo){
        for(cliente c : clientes){
            if(c.getCodigo() == codigo){
                return 1;
            }
        }
        return 0;
    }
    public cliente buscaCliente(int codigo){
        for(cliente c : clientes){
            if(c.getCodigo() == codigo){
                //System.out.println("Cliente encontrado com sucesso!");
                return c;
            }
        }
        //System.err.println("Cliente nao encontrado!");
        return null;
    }
    
    public int getIndiceCliente(cliente c){
        return clientes.indexOf(c);
    }
    
    public void setCliente(int indice, cliente c){
        clientes.set(indice, c);
    }
    
    public ArrayList<cliente> getClientes(){
        return clientes;
    }
}
