
package Modelo.Persistencia;
import Modelo.Entidade.venda;
import java.util.ArrayList;
import java.util.Scanner;

public class VendaDAO {
    private ArrayList<venda> vendas;

    public VendaDAO() {
        vendas = new ArrayList();
    }
    
    public int adicionaVenda(ProdutoDAO listaProdutos, int codigo, int clienteDaVenda, String enderecoDeEntrega, String status, String dataInicio, int codigoProduto, int qtde){
        for(venda v : vendas){
            if(v.getCodigo() == codigo){
                //System.err.println("Venda ja cadastrada!");
                return 0;
            }
        }
        venda vend = new venda(codigo, dataInicio, status, clienteDaVenda, enderecoDeEntrega);
        Scanner scanf = new Scanner(System.in);
        double prc;
        prc = listaProdutos.buscaProduto(codigoProduto, qtde);
        if(prc == -1){
            //System.err.println("Cadastre um produto para realizar a venda!");
            return -1;
        }
        if(prc == 0.0){
            return 0;
        }
        vend.insereProdutoVendido(qtde, codigoProduto, prc);
        vendas.add(vend);
        return 1;
    }
    
    public int removeVenda(int codigo){
        for(venda v : vendas){
            if(v.getCodigo() == codigo){
                vendas.remove(v);
                //System.out.println("Venda removida com sucesso!");
                return 1;
            }
        }
        //System.err.println("Venda para remocao nao encontrada!");
        return 0;
    }
    
    public venda buscaVenda(int codigo){
        for(venda v : vendas){
            if(v.getCodigo() == codigo){
                //System.out.println("Venda encontrada com sucesso!");
                return v;
            }
        }
        //System.err.println("Venda nao encontrada!");
        return null;
    }
    
    public int buscaVenda2(int codigo){
        for(venda v : vendas){
            if(v.getCodigo() == codigo){
                //System.out.println("Venda encontrada com sucesso!");
                return 1;
            }
        }
        //System.err.println("Venda nao encontrada!");
        return 0;
    }
    
    public void setListaVendas(venda v, int indice){
        vendas.set(indice, v);
    }
    
    public int getIndiceVenda(venda v){
        return vendas.indexOf(v);
    }
    
    public ArrayList<venda> getVendas(){
        return vendas;
    }
}
