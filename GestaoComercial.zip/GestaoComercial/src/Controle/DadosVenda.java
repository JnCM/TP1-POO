
package Controle;
import Modelo.Persistencia.VendaDAO;
import Modelo.Entidade.venda;

public class DadosVenda {
    private VendaDAO listaVendas;

    public DadosVenda() {
        listaVendas = new VendaDAO();
    }
    
    public int addVenda(DadosProduto listaProdutos, int codigoVenda, int codigoCliente, String endereco, String status, String dataInicio, int codigoProduto, int qtde){
        int verifica = listaVendas.adicionaVenda(listaProdutos.getListaProdutos(), codigoVenda, codigoCliente, endereco, status, dataInicio, codigoProduto, qtde);
        return verifica;
    }
    
    public int removVenda(int codigo){
        int verifica = listaVendas.removeVenda(codigo);;
        return verifica;
    }
    
    public int buscVenda(int codigo){
        return listaVendas.buscaVenda2(codigo);
    }
    
    public int alteraVenda(int codigo, String status, String dataFim){
        int indice, verifica;
        venda aux;
        aux = listaVendas.buscaVenda(codigo);
        indice = listaVendas.getIndiceVenda(aux);
        aux.setStatus(status);
        if(status.equals("Entregue")){
            aux.setDataFim(dataFim);
        }
        listaVendas.setListaVendas(aux, indice);
        //System.out.println("Venda alterada com sucesso!");
        return 1;
    }
    
    public VendaDAO getListaVendas(){
        return listaVendas;
    }
}
