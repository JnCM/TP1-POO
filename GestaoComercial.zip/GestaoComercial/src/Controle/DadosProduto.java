
package Controle;

import Modelo.Persistencia.ProdutoDAO;

public class DadosProduto {
    private ProdutoDAO listaProdutos;

    public DadosProduto() {
        listaProdutos = new ProdutoDAO();
    }
    public int addProduto(int codigo, String descricao, int qtdeEmEstoque, String categoria, double preco){
        int verifica = listaProdutos.adicionaProduto(codigo, descricao, qtdeEmEstoque, categoria, preco);
        return verifica;
    }
    public int removProduto(int codigo){
        int verifica = listaProdutos.removeProduto(codigo);
        return verifica;
    }
    public ProdutoDAO getListaProdutos() {
        return listaProdutos;
    }
    public int buscProduto(int codigo){
        return listaProdutos.buscaProduto2(codigo);
    }
}
