
package Controle;
import Modelo.Persistencia.ClienteDAO;
import Modelo.Entidade.cliente;

public class DadosCliente {
    private ClienteDAO listaClientes;

    public DadosCliente() {
        listaClientes = new ClienteDAO();
    }
    
    public int addCliente(int codigo, String nome, String cpf, String email, String senha){
        int verifica;
        if(codigo <= 0 || nome.equals("") || email.equals("") || senha.equals("") || cpf.equals("")){
            return 0;
        }
        verifica = listaClientes.adicionaCliente(codigo, cpf, nome, email, senha);
        if(verifica == 0){
            return -1;
        }
        if(verifica == -1){
            return -2;
        }
        if(verifica == -2){
            return -3;
        }
        if(verifica == 1){
            return 1;
        }
        return 0;
    }
    
    public int addEndereco(int codigo, String rua, String bairro, String cidade, int numero){
        int verifica = listaClientes.adicionaEndereco(codigo, rua, bairro, cidade, codigo);
        return verifica;
    }
    
    public int removCliente(int codigo){
        int verifica;
        verifica = listaClientes.removeCliente(codigo);
        return verifica;
    }
    
    public int alteraDadosCliente(int codigo, String email, String senha, String rua, String bairro, String cidade, int numero){
        int indiceCliente;
        cliente aux;
        aux = listaClientes.buscaCliente(codigo);
        indiceCliente = listaClientes.getIndiceCliente(aux);
        if(email.equals("") && senha.equals("") && !(rua.equals("") && bairro.equals("") && cidade.equals(""))){
            aux.insereEnderecos(rua, bairro, cidade, numero);
            listaClientes.setCliente(indiceCliente, aux);
        }
        else if(senha.equals("") && rua.equals("") && bairro.equals("") && cidade.equals("") && !email.equals("")){
            for(cliente c : listaClientes.getClientes()){
                if(c.getEmail().equals(email)){
                    //System.err.println("Email ja cadastrado!");
                    return 0;
                }
            }
            aux.setEmail(email);
            listaClientes.setCliente(indiceCliente, aux);
        }    
        else if(email.equals("") && rua.equals("") && bairro.equals("") && cidade.equals("") && !senha.equals("")){
            aux.setSenha(senha);
            listaClientes.setCliente(indiceCliente, aux);
        }
        else if(senha.equals("") && !(rua.equals("") && bairro.equals("") && cidade.equals("") && email.equals(""))){
            for(cliente c : listaClientes.getClientes()){
                if(c.getEmail().equals(email)){
                    //System.err.println("Email ja cadastrado!");
                    return 0;
                }
            }
            aux.setEmail(email);
            aux.insereEnderecos(rua, bairro, cidade, numero);
            listaClientes.setCliente(indiceCliente, aux);
        }
        else if(email.equals("") && !(rua.equals("") && bairro.equals("") && cidade.equals("") && senha.equals(""))){
            aux.setSenha(senha);
            aux.insereEnderecos(rua, bairro, cidade, numero);
            listaClientes.setCliente(indiceCliente, aux);
        }
        else if(rua.equals("") && bairro.equals("") && cidade.equals("") && !(email.equals("") && senha.equals(""))){
            aux.setSenha(senha);
            for(cliente c : listaClientes.getClientes()){
                if(c.getEmail().equals(email)){
                    //System.err.println("Email ja cadastrado!");
                    return 0;
                }
            }
            aux.setEmail(email);
            listaClientes.setCliente(indiceCliente, aux);
        }
        else{
            aux.setSenha(senha);
            aux.insereEnderecos(rua, bairro, cidade, numero);
            for(cliente c : listaClientes.getClientes()){
                if(c.getEmail().equals(email)){
                    //System.err.println("Email ja cadastrado!");
                    return 0;
                }
            }
            aux.setEmail(email);
            listaClientes.setCliente(indiceCliente, aux);
        }
        //System.out.println("Dados do cliente alterado com sucesso!");
        return 1;
    }
    public ClienteDAO getListaClientes(){
        return listaClientes;
    }
    public int buscCliente(int codigo){
        return listaClientes.buscaCliente2(codigo);
    }
}
