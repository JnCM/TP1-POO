#include <stdio.h>
#include <stdlib.h>
#include "MENU.h"

int main(){
	menu1();
  return 0;
}
