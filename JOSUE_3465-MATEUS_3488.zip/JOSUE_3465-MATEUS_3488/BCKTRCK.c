#include <stdio.h>
#include <stdlib.h>
#include "BCKTRCK.h"
#define Analise 0

int VerificaParede(int i, int j, char** matriz){
	if(matriz[i][j] == '2'){
		return 1;
	}
	return 0;
}

int VerificaPorta(int i, int j, char** matriz){
	if(matriz[i][j] == '3'){
		return 1;
	}
	return 0;
}

int movimenta_estudante(int MaxLin, int MaxCol, int i, int j, char** matriz, TipoLista *Pilha, TipoLista *Lista, int *QntdChaves, int *Movimentos, int *Recursiva, int *MAX, int *Total){
	if(Analise == 1){
		(*Recursiva)++;
		(*Total)++;
		if(MAX < Recursiva){
			(*MAX) = (*Recursiva);
		}
	}
	printf("Linha %d e coluna %d \n", i, j);
	Insere(i, j, Lista);
	Insere(i, j, Pilha);
	if(i == 0){
		printf("\nO estudante se movimentou %d vezes e chegou na coluna %d da primeira linha\n",(*Movimentos),j);
		Imprime(*Pilha);
		if(Analise == 1){
			printf("\nO total de chamadas recursivas foi de: %d, e o numero maximo de recursivas simultaneas foi de: %d", (*Total), (*MAX));
			(*Recursiva)--;
		}
		return 1;
	}
	//CIMA
	if(VerificaParede(i-1, j, matriz) == 0){
		if(VerificaPorta(i-1, j, matriz) == 1 && (*QntdChaves) >= 1){
			if(Busca(i-1, j, *Lista) != 0){
				(*QntdChaves)--;
				(*Movimentos)++;
				if(movimenta_estudante(MaxLin, MaxCol, i-1, j, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
					(*Recursiva)--;
					return 1;
				}
				(*QntdChaves)++;
				Remove(Pilha);
				printf("Linha %d e coluna %d \n", i, j);
				(*Movimentos)++;
			}
		}
		else if(VerificaPorta(i-1, j, matriz) == 0){
			if(Busca(i-1, j, *Lista) != 0){
				(*Movimentos)++;
				if(movimenta_estudante(MaxLin, MaxCol, i-1, j, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
					(*Recursiva)--;
					return 1;
				}
				Remove(Pilha);
				printf("Linha %d e coluna %d \n", i, j);
				(*Movimentos)++;
			}
		}
	}
	//DIREITA
	if(j != MaxCol - 1){
		if(VerificaParede(i, j+1, matriz) == 0){
			if(VerificaPorta(i, j+1, matriz) == 1 && (*QntdChaves) >= 1){
				if(Busca(i, j+1, *Lista) != 0){
					(*QntdChaves)--;
					(*Movimentos)++;
					if(movimenta_estudante(MaxLin, MaxCol, i, j+1, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
						(*Recursiva)--;
						return 1;
					}
					(*QntdChaves)++;
					Remove(Pilha);
					printf("Linha %d e coluna %d \n", i, j);
					(*Movimentos)++;
				}
			}
			else if(VerificaPorta(i, j+1, matriz) == 0){
				if(Busca(i, j+1, *Lista) != 0){
					(*Movimentos)++;
					if(movimenta_estudante(MaxLin, MaxCol, i, j+1, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
						(*Recursiva)--;
						return 1;
					}
					Remove(Pilha);
					printf("Linha %d e coluna %d \n", i, j);
					(*Movimentos)++;
				}
			}
		}
	}
	//ESQUERDA
	if(j != 0){
		if(VerificaParede(i, j-1, matriz) == 0){
			if(VerificaPorta(i, j-1, matriz) == 1 && (*QntdChaves) >= 1){
				if(Busca(i, j-1, *Lista) != 0){
					(*QntdChaves)--;
					(*Movimentos)++;
					if(movimenta_estudante(MaxLin, MaxCol, i, j-1, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
						(*Recursiva)--;
						return 1;
					}
					(*QntdChaves)++;
					Remove(Pilha);
					printf("Linha %d e coluna %d \n", i, j);
					(*Movimentos)++;
				}
			}
			else if(VerificaPorta(i, j-1, matriz) == 0){
				if(Busca(i, j-1, *Lista) != 0){
					(*Movimentos)++;
					if(movimenta_estudante(MaxLin, MaxCol, i, j-1, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
						(*Recursiva)--;
						return 1;
					}
					Remove(Pilha);
					printf("Linha %d e coluna %d \n", i, j);
					(*Movimentos)++;
				}
			}
		}
	}
	//BAIXO
	if(i != MaxLin - 1){
		if(VerificaParede(i+1, j, matriz) == 0){
			if(VerificaPorta(i+1, j, matriz) == 1 && (*QntdChaves) >= 1){
				if(Busca(i+1, j, *Lista) != 0){
					(*QntdChaves)--;
					(*Movimentos)++;
					if(movimenta_estudante(MaxLin, MaxCol, i+1, j, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
						(*Recursiva)--;
						return 1;
					}
					(*QntdChaves)++;
					Remove(Pilha);
					printf("Linha %d e coluna %d \n", i, j);
					(*Movimentos)++;
				}
			}
			else if(VerificaPorta(i+1, j, matriz) == 0){
				if(Busca(i+1, j, *Lista) != 0){
					(*Movimentos)++;
					if(movimenta_estudante(MaxLin, MaxCol, i+1, j, matriz, Pilha, Lista, QntdChaves, Movimentos, Recursiva, MAX, Total) == 1){
						(*Recursiva)--;
						return 1;
					}
					Remove(Pilha);
					printf("Linha %d e coluna %d \n", i, j);
					(*Movimentos)++;
				}
			}
		}
	}
	(*Recursiva)--;
	return 0;
}
