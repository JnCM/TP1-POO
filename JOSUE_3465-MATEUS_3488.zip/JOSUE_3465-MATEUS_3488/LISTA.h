typedef struct TipoCelula *TipoApontador;

typedef struct TipoCelula {
  int linha,coluna;
  TipoApontador Prox;
} TipoCelula;

typedef struct {
  TipoApontador Primeiro, Ultimo;
} TipoLista;

void FLVazia(TipoLista *Lista);
int Vazia(TipoLista Lista);
void Insere(int l, int c, TipoLista *Lista);
void Remove(TipoLista *Lista);
int Busca(int i, int j, TipoLista Lista);
void Imprime(TipoLista Lista);
