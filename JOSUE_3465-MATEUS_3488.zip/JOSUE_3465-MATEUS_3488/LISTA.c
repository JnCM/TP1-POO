#include <stdio.h>
#include <stdlib.h>
#include "LISTA.h"

void FLVazia(TipoLista *Lista){
  Lista -> Primeiro = (TipoApontador) malloc(sizeof(TipoCelula));
  Lista -> Ultimo = Lista -> Primeiro;
  Lista -> Primeiro -> Prox = NULL;
}

int Vazia(TipoLista Lista){
  return (Lista.Primeiro == Lista.Ultimo);
}

void Insere(int l, int c, TipoLista *Lista){
  Lista -> Ultimo -> Prox = (TipoApontador) malloc(sizeof(TipoCelula));
  Lista -> Ultimo = Lista -> Ultimo -> Prox;
  Lista -> Ultimo -> linha = l;
  Lista -> Ultimo -> coluna = c;
  Lista -> Ultimo -> Prox = NULL;
}

void Remove(TipoLista *Lista){
  if (Vazia(*Lista)){
    printf("Erro: lista vazia\n");
    return;
  }
  TipoApontador q;
  TipoApontador Aux;
  q = Lista->Primeiro;
  Aux = Lista -> Primeiro -> Prox;
  while (Aux->Prox != NULL){
    q = Aux;
    Aux = Aux -> Prox;
  }
  Lista->Ultimo = q;
  Lista->Ultimo->Prox = NULL;
  free(Aux);
}

int Busca(int i, int j, TipoLista Lista){
  TipoApontador Aux;
  Aux = Lista.Primeiro -> Prox;
  while (Aux != NULL){
    if(Aux->linha == i && Aux->coluna == j){
      return 0;
    }
    Aux = Aux -> Prox;
  }
  return 1;
}

void Imprime(TipoLista Lista){
  TipoApontador Aux;
  Aux = Lista.Primeiro -> Prox;
  printf("Caminho encontrado:\n");
  while (Aux != NULL){
    printf("Linha: %d Coluna: %d\n", Aux->linha, Aux->coluna);
    Aux = Aux -> Prox;
  }
}
