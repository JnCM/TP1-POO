#include <stdio.h>
#include <stdlib.h>
#include "MENU.h"

void menu1(){
  int linha, coluna, chaves, i, j, movs, recursivas, max, total, carregado;
  	char** matriz;
  	char opcao;
  	FILE *Arq;
  	TipoLista Pilha, Lista;
  	movs = 0;
  	recursivas = 0;
  	max = 0;
  	total = 0;
  	FLVazia(&Pilha);
  	FLVazia(&Lista);
  	do{
		printf("-----------------------------------------------\n");
		printf("|                                             |\n");
		printf("|                  Bem-Vindo                  |\n");
		printf("|                                             |\n");
		printf("| 1 - Carregar um Novo Arquivo                |\n");
		printf("| 2 - Procurar Caminho do Arquivo Carregado   |\n");
		printf("| 3 - Sair Do Programa                        |\n");
		printf("|                                             |\n");
		printf("-----------------------------------------------\n");
		scanf("%d", &opcao);
		if(opcao == 1){
      char NomeArq[12];
      printf("Digite o nome do arquivo na forma: entrada.txt\n");
      scanf("%s", NomeArq);
			Arq = fopen(NomeArq,"r");
		  	fscanf(Arq,"%d %d %d",&linha,&coluna,&chaves);
		  	matriz = (char**)malloc(linha*sizeof(char*));
		  	for(i=0;i<linha;i++){
		    	matriz[i] = (char*)malloc(coluna*sizeof(char));
		  	}
		  	for(i=0;i<linha;i++){
		    	for(j=0;j<coluna;j++){
		      		fscanf(Arq,"%c",&matriz[i][j]);
		      		if(matriz[i][j] == '\n' || matriz[i][j] == ' '){
		      		fscanf(Arq,"%c",&matriz[i][j]);
			  		}
		    	}
		  	}
		  	fclose(Arq);
        printf("Arquivo Carregado com sucesso!\n");
		  	carregado = 1;
		}
		else if(opcao == 2){
			if(carregado == 1){
				printf("%d %d %d\n", linha, coluna, chaves);
	  			for(i=0;i<linha;i++){
	    			for(j=0;j<coluna;j++){
	      				if(matriz[i][j] == '0'){
	        				if(movimenta_estudante(linha, coluna, i, j, matriz, &Pilha, &Lista, &chaves, &movs, &recursivas, &max, &total) == 0){
	        					printf("\nO estudante se movimentou %d vezes e chegou na linha %d da coluna %d, para entao percebeer que nao havia saida do labirinto\n",movs, i, j);
								if(Analise == 1){
									printf("\nO total de chamadas recursivas foi de: %d, e o numero maximo de recursivas simultaneas foi de: %d",total, max);
								}
							}
	       					break;
	    				}
	    			}
	  			}
	  			opcao = 3;
			}
			else{
				printf("Carregue um arquivo primeiro!!\n");
			}
		}
		else{
			opcao = 3;
		}
	}while(opcao != 3);
}
