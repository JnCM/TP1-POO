#include "LISTA.h"

int VerificaParede(int i, int j, char** matriz);
int VerificaPorta(int i, int j, char** matriz);
int movimenta_estudante(int MaxLin, int MaxCol, int i, int j, char** matriz, TipoLista *Pilha, TipoLista *Lista, int *QntdChaves, int *Movimentos, int *Recursiva, int *MAX, int *Total);
